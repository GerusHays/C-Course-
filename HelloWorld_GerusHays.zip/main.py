"""
Developer: Gerus Hays
Date: July 5, 2025
Purpose: This is a simple 'Hello, world!' program written in Python.
         It demonstrates basic syntax and output in Python.
"""

# Print a greeting message to the console
print("Hello, world!")